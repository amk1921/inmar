# Questions

1. How do the following components get deployed in your current work environment,
   from brain to production?

**a. Application code**
    **Distributed Version Control System** Maintain a distributed version control system to track/commit application code changes in a remote repository. We can follow different strategies/branches to differentiate the code from each developer and can also maintain stable release versions
    **Developer Environment** Every developer assigned with a conduit AWS account where he/she can deploy his application infrastructure using CDK cloudfromation stack to test against his application code
    **Local Dev Testing** Every developer creates his/her own branch from the stable branch from git. After the development work is done, he/she can deploy his stack/code cahnges (mostly working with serverless lambda funtions) in his Dev Conduit AWS account and test in it.
    **Code Coverage/Unit Testing** We also follow standard test integration with application code (unit test cases) which helps us to test the lines of code coverage. The particular code commit/merge cannot be done if the code coverage with unit tests doesn't match above 95%.
    **Code Review** Upon successful testing application code in local development environment, each developer will raise a CR (Change Review) and he/she attach his test cases in the same. This CR requires minimal 2 peer approvals to make a successful merge to mainline branch.
    **Deployment** Upon successful merge, we have 3 deployment environment setup for actual testing of application using pipelines
    **Beta Environment** This environment is being used by developers to test their changes in lower environment.
    **Gamma Environment** This environment is being used by testing team to perform load/penetration/integration testing
    **Production Environment** Upon passing all tests, the code is deployed/promoted to the production environment. We internally discuss and scheulde the production deployent window and will also send a communication mail if the production deployment requires a downtime.

**b. Configuration**
    **Configuration Management** Use tools like Ansible to write and manage configuration files.
    **Version Control and Review** Configuration files are stored in version control and undergo peer review and testing in staging environments.
    **Managing Secrets** Use ansible vault or Amazon Secret Manager to store (encrypt/decrypt) and retrieve the passwords/secrets/API Keys/Tokens.

**c. Infrastructure**
    **Infrastructure as Code (IaC)** We use Cloud Development Kit (CDK) with Typescript (A programming way of creating and managing infrastructure) to create AWS infrastructure. Upon building the code, it converts the code into CloudFormation stacks/templates and ready to deploy/create/manage the infrastructre using CloudFormation service in AWS.
    **Testing** Use linting, unit testing & integration testing to test the deployments
    **Provisioning** The IaC is applied to provision resources in the cloud, ensuring consistent infrastructure across environments.

2. In your opinion, what is the purpose of an incident post-mortem?
   **History of Incident** Analyse if the incident occured for the first time or there were any previous incidents on the same. Analyse why it is repeated, what were the actions taken if it is a repeated incident.
   **Incident Analysis** Understand what went wrong, including the root cause and contributing factors. Go through the metrics, logs and events for the deep dive of identifying the root cause.
   **Process Improvement** Identify the gaps in processes, monitoring, or communication that allowed the incident to occur or exacerbated its impact.
   **Knowledge Share** Share knowledge and lessons learned with the team to prevent similar incidents in the future.
   **Docuentation** If possible, create a document with the steps followed to fix the issue for trakcing purpose.
   **Bug fix:** If it is a bug in the application, create a development ticket and assign to a developer to fix the root cause permanently. Create actionable steps to address the root causes and improve the system's resilience and reliability.

3. How do you handle (and feel about) making changes (code/schema/network/etc.) in
   your current environment? How do you know the changes you made did not break
   anything?
   **Planning** Changes are planned, reviewed with the team, and approved through a change management process.
   **HLD/LLD/1-Pager** Prepare standard documents with the changes you want to implement and get it reviewed with SDEs and work up on their valuable comments then get it sign off for the implementation.
   **Incremental Changes** Make small, incremental changes rather than large, sweeping updates.
   **Reviews** Code and configuration changes are peer-reviewed to catch potential issues early.
   **Testing** Extensive testing is performed, including unit tests, integration tests, and system tests.
   **Automated Pipelines** Automated pipelines run tests and deploy changes in a controlled manner.
   **Monitoring and Logging** Comprehensive monitoring and logging are in place to detect issues early.
   **Rollback Plans** Have rollback plans in place to quickly revert changes if issues arise.
   **Standard Deployment Strategy** Follow Blue-Green aor Canary deployment strategies to maintain zero-down at the time application upgrde.
   **Regular Patching** To avoid dependency version vulnerabilities, update the versions regularly.
   **Staging Environments** Changes are deployed to staging environments for thorough testing before going to production.
   **Confidence** With robust processes and tools in place, changes can be made confidently.
   **Responsibility** There is a sense of responsibility to ensure changes do not negatively impact the system.
   **Readiness** Being prepared to address any issues that arise from changes.
   **Observability** Continuously observe/monitor the recent deployment for any fault tolerasnce or issues and be ready to identify the root cause then fix ASAP

4. Let's say you have a directory that contains other directories, that contain
   database files, that have these characteristics:

```bash
$ du -sh /data/
960G   /data/
$ find . -type d | wc -l
920
$ find . -type f | wc -l
353260
```

- What are 3 methods to copy this entire directory structure from one server to
  another?
  **scp** scp is a secure copy functionality used to copy files/directories from one server to another server
    scp -r source_user@source_server:/data/ remote_user@remote_server:/path/to/destination/

    As we are copying very large sized file/directory, we can run this process in background
      nohup scp -r source_user@source_server:/data/ remote_user@remote_server:/path/to/destination/ &

  **rsync** Rsync, which stands for remote sync, is a remote and local file synchronization tool. It uses an algorithm to minimize the amount of data copied by only moving the portions of files that have changed.
    rsync -avzh source_user@source_server:/data/ remote_user@remote_server:/path/to/destination/

  **Compress and scp** As we are copying very large file/directory, we can make use of compress techniques to reduce the size of directory/file then copy to destination server
    tar -czf compressed_data.tar.gz /data/
    scp -r source_user@source_server:compressed_data.tar.gz remote_user@remote_server:/path/to/destination/

  **FTP**
  1. cd to source directory
  2. Establish a ftp connection to remote server
  3. cd to a destination directory
  4. put /data/*

- What are any methods to speed up this transfer?
    **Compression and Archiving** Compressing your files into ZIP or RAR archives before transferring them can reduce their size, leading to quicker transfers. Many compression tools are available for this purpose, and they can save both time and bandwidth.
    **Limit Background Processes** Before initiating a file transfer, pause or close any unnecessary background processes or applications that might be consuming your bandwidth. This ensures that more of your available bandwidth is dedicated to the transfer itself.
    **Parallel Transfers** Use tools like rsync with parallel options or scp with -C (compression) to speed up the transfer.
    **Peer-to-Peer (P2P) Transfers** P2P file sharing can be a game-changer, especially for large files. Applications dedicated to this enable users to download and upload files from multiple sources to help increase transfer speed.

- How can you measure the resource usage of any of these different methods of
  transfer?
    **top/htop** Use system build-in process monitoring tools to monitor CPU/MEM usage of a particular process
    **Metrics & Monitoring** Establish monitoring solutions/tools like prometheus or grafana to visualize and track resource usage metrics during the transfer.

