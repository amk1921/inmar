import time
from flask import Flask, request
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import relationship

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://user:super-secret-password@db:5432/test'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class Moment(db.Model):
    __tablename__ = 'moments'
    mid = db.Column('id', db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=False, nullable=False)
    parent_id = db.Column(db.Integer, db.ForeignKey('moments.id'))
    parent = relationship('Moment', remote_side=[mid], backref='children')

    def __repr__(self):
        return f'<Moment {self.name} parent_id:{self.parent_id}>'

@app.route('/')
def index():
    mid = request.args.get('id', default=1, type=int)
    moment = db.session.get(Moment, mid)
    return str(moment)

@app.route('/moments/<int:mid>/descendants')
def descendants(mid):
    parent = db.session.get(Moment, mid)
    if not parent:
        return "Moment not found", 404

    def get_descendants(moment, level=0):
        lines = [(" " * level * 4) + moment.name]
        for child in moment.children:
            lines.extend(get_descendants(child, level + 1))
        return lines

    descendants_list = get_descendants(parent)
    return "\n".join(descendants_list)

def wait_for_db():
    retries = 5
    while retries > 0:
        try:
            db.session.execute('SELECT 1')
            return
        except Exception as e:
            retries -= 1
            time.sleep(5)
    raise Exception('Database connection failed')

with app.app_context():
    wait_for_db()
    db.create_all()

if __name__ == '__main__':
    app.run(host='0.0.0.0')
    
